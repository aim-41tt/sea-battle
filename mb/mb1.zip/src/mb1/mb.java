package mb1;



public class mb {

	public static void main(String[] args) {
		
		new okno();
	}

}
